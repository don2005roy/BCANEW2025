from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
import pickle
from django.conf import settings
import cv2
from firebase import firebase

from PIL import Image
import base64

import matplotlib.pyplot as plt
from io import StringIO
import qrcode

from datetime import timedelta, date
import pandas as pd
import xlwt
from xlwt import Workbook


config = {
    "apiKey":"AIzaSyB4q-zEJzOjwR69oT1F24tJa-RyGw7BHUQ",
    "authDomain":"qr-code-attendance-syste-68dd9.firebaseapp.com",
    "databaseURL":"https://qr-code-attendance-syste-68dd9-default-rtdb.firebaseio.com",
    "storageBucket":"qr-code-attendance-syste-68dd9.appspot.com"
    }

firebaseconn = firebase.FirebaseApplication(config["databaseURL"],None)

def dashboard(request):

    return render(request, "dashboard.html")

def submitattendance(request):
    if request.method == "POST":
        subject = request.POST.get('selectsubject')
        print(subject)

        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        detector = cv2.QRCodeDetector()

        while True:
            ret, img = cap.read()
            if not ret:
                print("Error: Failed to capture frame")
                continue
            
            if img is None:
                print("Error: Captured frame is empty")
                continue

            img = cv2.resize(img, (320, 240))
            data, bbox, _ = detector.detectAndDecode(img)

            cv2.imshow("Frame", img)  # Show the captured frame
            if cv2.waitKey(1) == ord('q'):  # Press 'q' to quit
                break
            if data:
                rollno = data
                print(rollno)
                break

        try:
            students = firebaseconn.get('Students', '')
            students_ids = []

            for i in students:
                students_ids.append(i)

            if rollno in students_ids:
                attendance_data = {"" + str(date.today()): "Present"}
                result = firebaseconn.patch('/Students/%s/Attendance/%s' % (rollno, subject), attendance_data)
                cap.release()
                cv2.destroyAllWindows()
                return render(request, "submitattendance.html", context={"mymessage": "Attendance Submitted for Roll No : " + rollno, "Flag": "True", "Navigate": "True"})
            else:
                return render(request, "submitattendance.html", context={"mymessage": "Student with this ID does not exist", "Flag": "True", "Navigate": "True"})
        except Exception as e:
            print("Exception:", e)
            pass

        return render(request, "submitattendance.html", context={"mymessage": "Please Connect with admin to create your account", "Flag": "True", "Navigate": "True"})

    return render(request, "submitattendance.html")

def viewhistory(request):

    if request.method == "POST":
        inputroll = request.POST.get('inputroll')
        print(inputroll)
        result=firebaseconn.get('Students/'+inputroll+'/Attendance','')

        if result == None:
            return render(request, "viewhistory.html", context={"mymessage":"Student with this roll no does not exist","Flag":"True"})
        else:
            IOT = []
            CC = []
            IPCV = []
            for i in result:
                if result[i] != "":
                    for j in result[i].keys():
                        if i == "IOT":
                            IOT.append(j)
                        if i == "CC":
                            CC.append(j)
                        if i == "IPCV":
                            IPCV.append(j)

            print(IOT)
            print(CC)
            print(IPCV)
            return render(request, "viewhistory.html",context = {"IOT":IOT, "CC":CC, "IPCV":IPCV})

    return render(request, "viewhistory.html")

def adminpanel(request):

    qr_fig = plt.figure(figsize=(5, 5))
    plt.axis('off')
    plt.imshow(Image.open("qrsample.png"))

    imagedata = StringIO()
    qr_fig.savefig(imagedata, format='svg')
    imagedata.seek(0)


    if request.method == "POST":
        inputrollno = request.POST.get('inputrollno')
        inputname = request.POST.get('inputname')
        inputaddress = request.POST.get('inputaddress')
        inputbranch = request.POST.get('inputbranch')
        inputcourse = request.POST.get('inputcourse')
        inputsemester = request.POST.get('inputsemester')
        inputyear = request.POST.get('inputyear')

        print(inputrollno)
        print(inputname)
        print(inputaddress)
        print(inputbranch)
        print(inputcourse)
        print(inputsemester)
        print(inputyear)

        #create student id
        basewidth = 100

        wpercent = (basewidth)
        hsize = int(float(wpercent))
        QRcode = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_H
        )

        rollno = inputrollno

        QRcode.add_data(rollno)
        QRcode.make()

        QRimg = QRcode.make_image(back_color="white").convert('RGB')

        QRimg.save('studentid.png')

        msg = "Student ID Generated"

        qr_fig = plt.figure(figsize=(5, 5))
        plt.axis('off')
        plt.imshow(Image.open('studentid.png'))

        imagedata = StringIO()
        qr_fig.savefig(imagedata, format='svg')
        imagedata.seek(0)

        print(msg)
        
        attendance_data = {"IOT":"",
        "CC":"",
        "IPCV":""}

        data = {"RollNo":inputrollno,
        "Name":inputname,
        "Address":inputaddress,
        "Branch":inputbranch,
        "Course":inputcourse,
         "Semester":inputsemester,
         "Year":inputsemester,
         "Attendance":attendance_data}

        try:
            students=firebaseconn.get('Students','')
            students_ids = []

            for i in students:
                students_ids.append(i)

            if inputrollno in students_ids:
                return render(request, "adminpanel.html", context={"msg":"Student with this ID already exist","Flag":"True"})
            else:
                result = firebaseconn.patch('/Students/%s/'%inputrollno,data)
                return render(request, "adminpanel.html", context={"pic":imagedata.getvalue(),"msg":"Details Submitted To DB","Flag":"True"})

        except:
            pass

        result = firebaseconn.patch('/Students/%s/'%inputrollno,data)
        return render(request, "adminpanel.html", context={"pic":imagedata.getvalue(),"msg":"Details Submitted To DB","Flag":"True"})

    return render(request, "adminpanel.html", context={"pic":imagedata.getvalue()})

def editdetails(request):

    if request.method == "POST":
        fieldname = request.POST.get("editfield")
        rollno = request.POST.get('editrollno')
        newvalue = request.POST.get('newvalue')

        print(fieldname)
        print(rollno)

        students=firebaseconn.get('Students','')
        students_ids = []
        for i in students:
            students_ids.append(i)

        if rollno not in students_ids:
            return render(request, "editdetails.html", context={"msg":"Student with this ID does not exist","Flag":"True"})
        else:
            result = firebaseconn.patch('/Students/%s/'%rollno,{fieldname:newvalue})
            return render(request, "editdetails.html", context={"msg":"Value Updated in DB","Flag":"True"})

    return render(request, "editdetails.html")

def viewstudenthistory(request):

    if 'generatereport' in request.POST:
        inputrollno = request.POST.get('inputrollno')

        result=firebaseconn.get('Students/'+inputrollno+'/Attendance','')
        if result == None:
            return render(request, "viewstudenthistory.html", context={"mymessage":"Student with this roll no does not exist","Flag":"True"})
        else:
            IOT = []
            CC = []
            IPCV = []
            for i in result:
                if result[i] != "":
                    for j in result[i].keys():
                        if i == "IOT":
                            IOT.append(j)
                        if i == "CC":
                            CC.append(j)
                        if i == "IPCV":
                            IPCV.append(j)


            all_dates = []

            for i in range(31):
                current_date = date.today() + timedelta(days=-i)
                all_dates.append(current_date.strftime("%Y-%m-%d"))
                
            print(all_dates)

            IOT_Attendance = []
            CC_Attendance = []
            IPCV_Attendance = []

            IOT_present_days_count = 0
            CC_present_days_count = 0
            IPCV_present_days_count = 0

            for i in all_dates:
                if i in IOT:
                    IOT_present_days_count += 1
                    IOT_Attendance.append("IOT "+str(i)+" Present")
                else:
                    IOT_Attendance.append("IOT "+str(i)+" Absent")

            for i in all_dates:
                if i in CC:
                    CC_present_days_count += 1
                    CC_Attendance.append("CC "+str(i)+" Present")
                else:
                    CC_Attendance.append("CC "+str(i)+" Absent")

            for i in all_dates:
                if i in IPCV:
                    IPCV_present_days_count += 1
                    IPCV_Attendance.append("IPCV "+str(i)+" Present")
                else:
                    IPCV_Attendance.append("IPCV "+str(i)+" Absent")


            IOT_percentage = (IOT_present_days_count/30) * 100
            CC_percentage = (CC_present_days_count/30) * 100
            IPCV_percentage = (IPCV_present_days_count/30) * 100

            

            subjects = []
            dates = []
            status = []

            wb = Workbook()

            sheet1 = wb.add_sheet('Sheet 1')

            ###

            subjects.clear()
            dates.clear()
            status.clear()

            for i in IOT_Attendance:
                subjects.append(i.split(" ")[0])
                dates.append(i.split(" ")[1])
                status.append(i.split(" ")[2])


            sheet1.write(0, 0, 'Subject')
            sheet1.write(0, 1, 'Dates')
            sheet1.write(0, 2, 'Status')

            for i in range(len(subjects)):
                sheet1.write(i+1,0, subjects[i])
                sheet1.write(i+1,1, dates[i])
                sheet1.write(i+1,2, status[i])

            #################

            subjects.clear()
            dates.clear()
            status.clear()

            for i in CC_Attendance:
                subjects.append(i.split(" ")[0])
                dates.append(i.split(" ")[1])
                status.append(i.split(" ")[2])


            sheet1.write(0, 4, 'Subject')
            sheet1.write(0, 5, 'Dates')
            sheet1.write(0, 6, 'Status')

            for i in range(len(subjects)):
                sheet1.write(i+1,4, subjects[i])
                sheet1.write(i+1,5, dates[i])
                sheet1.write(i+1,6, status[i])

            ###
            subjects.clear()
            dates.clear()
            status.clear()

            for i in IPCV_Attendance:
                subjects.append(i.split(" ")[0])
                dates.append(i.split(" ")[1])
                status.append(i.split(" ")[2])


            sheet1.write(0, 8, 'Subject')
            sheet1.write(0, 9, 'Dates')
            sheet1.write(0, 10, 'Status')

            for i in range(len(subjects)):
                sheet1.write(i+1,8, subjects[i])
                sheet1.write(i+1,9, dates[i])
                sheet1.write(i+1,10, status[i])

            sheet1.write(33,0,"Total Lectures attend in subject IOT : "+str(IOT_present_days_count)+" ")

            sheet1.write(34,0,"Total Lectures attend in subject CC : "+str(CC_present_days_count)+" ")

            sheet1.write(35,0,"Total Lectures attend in subject IPCV : "+str(IPCV_present_days_count)+" ")
            
            ##percentage
            sheet1.write(37,0,"Total Percentage in IOT "+"{0:.2f}%".format(IOT_percentage))

            sheet1.write(38,0,"Total Percentage in CC "+"{0:.2f}%".format(CC_percentage))

            sheet1.write(39,0,"Total Percentage in IPCV "+"{0:.2f}%".format(IPCV_percentage))

            #total percetage
            print("{0:.2f}%".format(IOT_percentage))
            print("{0:.2f}%".format(CC_percentage))
            print("{0:.2f}%".format(IPCV_percentage))

            wb.save('report.xls')

    if 'viewreport' in request.POST:
        inputroll = request.POST.get('inputroll')
        print(inputroll)
        result=firebaseconn.get('Students/'+inputroll+'/Attendance','')

        if result == None:
            return render(request, "viewstudenthistory.html", context={"mymessage":"Student with this roll no does not exist","Flag":"True"})
        else:
            IOT = []
            CC = []
            IPCV = []
            for i in result:
                if result[i] != "":
                    for j in result[i].keys():
                        if i == "IOT":
                            IOT.append(j)
                        if i == "CC":
                            CC.append(j)
                        if i == "IPCV":
                            IPCV.append(j)

            print(IOT)
            print(CC)
            print(IPCV)
            return render(request, "viewstudenthistory.html",context = {"IOT":IOT, "CC":CC, "IPCV":IPCV})

    return render(request, "viewstudenthistory.html")